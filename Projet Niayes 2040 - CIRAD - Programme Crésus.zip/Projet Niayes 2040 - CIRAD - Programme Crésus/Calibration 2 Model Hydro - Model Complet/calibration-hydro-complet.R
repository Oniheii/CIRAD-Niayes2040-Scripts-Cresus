


# FONCTIONS PERSONNALISEES R-NIAYES 2040
source(file.path(getwd(),'functions_calibration-hydro-complet.R'))

#optimisation
opti_model(getwd())



#indice par station
obs= na.omit(extract_obs())
simul="simulation_6.0_50.00.0_0.0bilanid_0.0__0.0_6.0_50.0.csv"
reso="300.0"
dir_simul = "data/simulations"
obs_col = "piezostation"
reso_min = "300.0"
dir_raster = "data/rasters"

q = 0
Path_simul200 <- file.path(dir_simul, list_simul200[sample(1:length(list_simul200), 
                                                           1)])
piezostation <- rcsv_sep(Path_simul200)
piezostation <- subset(piezostation, select = c("id", "date", 
                                                obs_col))
piezostation <- transform(piezostation, piezostation = as.numeric(piezostation))
piezostation <- transform(piezostation, id = as.numeric(id))
piezostation$date <- stringr::str_sub(piezostation$date, 
                                      1, nchar(piezostation$date) - 6)

piezostation$date <- lubridate::parse_date_time(piezostation$date, 
                                                orders = c("ymd", "dmy", "mdy"), tz = "GMT")
ListIDcell <- Filter(function(x) grepl(".csv$", x), list.files(dir_raster, 
                                                               pattern = "idcell"))


stations <- read.csv(file.path(dir_raster, Filter(function(x) grepl(reso_min, 
                                                                    x), ListIDcell)), header = TRUE, sep = ";", dec = ",")
s_out <- c("THIOUCOUGNE", "PETIE", "BENDIOUGA", "TEBENE Pz")
stations <- stations[!(stations$stations %in% s_out), ]

library(dplyr)
stations <- stations %>% group_by(cellules) %>% summarize(zone = paste(sort(unique(stations)), 
                                                                       collapse = "_"))


piezostation <- left_join(piezostation, stations, by = c(id = "cellules"))
piezostation <- na.omit(piezostation)


names(piezostation)[names(piezostation) == "zone"] <- "stations"
piezostation <- dplyr::select(piezostation, -starts_with("id"))

write.csv2(piezostation, file.path("data", "observations", 
                                   "piezostation.csv"))



(piezostation[which((piezostation$date < "2014-01-01") & 
                      piezostation$piezostation > 0), ])

sum((piezostation[which((piezostation$date < "2014-01-01") & 
                          piezostation$piezostation >=0), ])$piezostation)


###### Var perm Optimal

reso="300.0"

list_indice<-list.files("output/indice_par_station",
                        pattern = ".csv$")

st<-rcsv_sep(file.path("output",
                       "indice_par_station",list_indice[1]))$zone


list_parametre=c("varperm",
                 "varstock",
                 "popHaIrrig",
                 "popHaUrb")

for (s in st){
  
  p<-c()
  for (idc in list_indice){
    d<-rcsv_sep(file.path("output",
                          "indice_par_station",idc))
    
    sr<-substr(tools::file_path_sans_ext(idc),
               14,nchar(tools::file_path_sans_ext(idc)))
    
    split_list<-(as.list(strsplit(sr, '_')[[1]]))
    
    sid <- data.frame(matrix(unlist(split_list),
                             nrow=1,
                             ncol=(length(split_list))))
    names(sid) <- list_parametre
    
    d1<-d[which(d$zone==s),c("rmsle","zone")]
    
    p<-rbind(p,cbind(sid,d1))    
  }
  write.csv2(p,file.path("output","Varp",
                         paste(s,".csv",sep="")))
}


##### GRAPHIQUE PAR SIMULATION


df<-rcsv_sep('output/tableau_rsme.csv')

list_o<-c()

for (i in 1:dim(df)[1]){
  
  o<-paste(df[i,4:5],collapse="__")
  o1<-paste(df[i,6:7],collapse="_")
  o<-paste(c(o,o1),collapse="_")
  list_o<-c(list_o,o)
}

obs<-na.omit(extract_obs())

for (o in unique(list_o)){
  
  #o<-gsub("[^_]*_(.*)", "\\1",o)
  #o<-gsub("[^_]*_(.*)", "\\1",o)
  
  s<-(Filter(function(x) grepl(".csv", x),
             list.files('data/simulations',pattern=o)))
  
  
  graph_station_simul(obs,s,o)}     


dir_raster="data/rasters"
ListIDcell <-Filter(function(x) grepl(".csv$", x),
                    list.files('data/rasters',pattern = "idcell"))

Filter(function(x) grepl(".csv$", x),
       list.files('data/rasters',pattern = "idcell"))

read.csv(file.path(dir_raster, Filter(function(x) grepl(reso, 
                                        x), ListIDcell)[1]),
         header = TRUE, sep = ";", dec = ",")
































#graphique par station
df<-rcsv_sep('output/tableau_rsme.csv')

list_o<-c()

for (i in 1:dim(df)[1]){
  
  o<-paste(df[i,4:7],collapse="_")
  list_o<-c(list_o,o)
}

#obs<-na.omit(extract_obs())


























