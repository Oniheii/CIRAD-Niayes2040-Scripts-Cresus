


# FONCTIONS PERSONNALISEES R-NIAYES 2040
source(file.path(getwd(),'functions_calibration-OCS.R'))

#### extraire les rasters simul�s

get_My_raster()

#### importation des rasters et calcul des indicateurs
library(raster)

rmse_urbain<-indicateur(bande=1)
rmse_irrigation<-indicateur(bande=2)

write.csv2(rmse_irrigation,file.path("output","rmse_irrigation2018.csv"))
write.csv2(rmse_urbain,file.path("output","rmse_urbain2018.csv"))

#### meilleurs simulations model espace irrigu� & urbain selon les indicateurs
rmse_ir<-rcsv_sep('output/rmse_irrigation2018.csv')[-1]
rmse_ur<-rcsv_sep('output/rmse_urbain2018.csv')[-1]

rmse_model<-rmse_ir[1:9]
rmse_model$rmsle<-rmse_ir$rmsle+rmse_ur$rmsle
rmse_model$rmse<-rmse_ir$rmse+rmse_ur$rmse
rmse_model$nash_sutcliffe<-rmse_ir$nash_sutcliffe+rmse_ur$nash_sutcliffe



write.csv2(rmse_model,file.path("output","rmse_model_urbain&irrigation2018.csv"))


#### analyse de sensibilit� model espace irrigu� & urbain

#- les param�tres d'entr�e
X<-rmse_model

X$route_vois<-ifelse(X$route_vois=='false',0,1)

rmse_norm<-data.frame(sapply(X,as.numeric))

rmse_norm[c(1:6,8:9)]<-round(data.frame(sapply(rmse_norm[c(1:6,
                                                           8:9)],normaliz_zero)),2)

#Plan One At Time (OAT)
pPlan<-sapply(data.frame(sapply(X,
                                as.numeric))[1:9],unique)

pPlan<- data.frame(lapply(pPlan, function(x) {
  x <- unlist(x)
  length(x) <- max(lengths(pPlan))
  return(x)
}))
pPlan
pPlan<-pPlan

poat<-rmse_norm


#m�thode de Morris: Le plan de morris avec �chantillonnage radial it�r�
set.seed(42)
i<-0
EE<-c()
PARAM<-c()
choc<-c()
response<-c()

while (i<10){
  i<- i+1
  t<-c()
  T<-0
  
  
  #premier plan OAT
  
  ##trier au hasard l'�tat initial des param�tre du plan OAT
  L0<-sample(dim(poat)[1],1)
  input0 <- poat[L0,1:9]
  
  ##appel initial au model (r�ponse du model au set initial de param�tres)
  output0 <- poat[L0,11]
  
  while (T<45){
    #effets elementaire
    ##tirage al�atoire pour modification d'une entr�e
    to<-sample(length(input0),1)
    
    ##modification du parametre choqu�:
    input1 <- input0
    
    c<-0
    
    lt<-(na.omit(unique(poat[[to]])))
    lt<-lt[lt!=input0[[to]]]
    
    while (c<1){
      chg<-sample(lt,1)[[1]]
      input1[to]<-chg
      
      y<-subset(poat,
                expCoeff==input1[["expCoeff"]] &
                  penteInfCoeff==input1[["penteInfCoeff"]] &
                  distrouteCoeff==input1[["distrouteCoeff"]] &
                  ratioliste==input1[["ratioliste"]]  &
                  voisUrbCoef==input1[["voisUrbCoef"]] &
                  routesCoef==input1[["routesCoef"]] &
                  route_vois==input1[["route_vois"]] &
                  popHaIrrig==input1[["popHaIrrig"]] &
                  popHaUrb==input1[["popHaUrb"]])
      
      
      ##le pas de changement
      d<-unlist(chg-input0[to])
      
      if (NROW(y)>0){
        c<-1}
      if (NROW(y)==0){
        input1 <- input0
        lt<-lt[lt!=chg]}}
    
    ##appel au model choqu�
    output1 <- y[11]
    input1 <- y[L0,1:9]
    
    ## effet �l�mentaire EE
    EE1<-(output1-output0)/d
    EE <-c (EE,round(EE1,3))
    PARAM<- c(PARAM,names(input1)[to])
    choc<-c(choc,d)
    response<-c(response,round((output1-output0),3))
    t<-c(t,to)
    T<-sum(unique(t))
  }
  
}

ee_morris <- data.frame(cbind(unlist(PARAM),
                              unlist(EE),
                              unlist(choc),
                              unlist(response)))
rownames(ee_morris) <-NULL 
ee_morris[2:4]<-sapply(ee_morris[2:4],as.numeric)
ee_morris[1]<-sapply(unlist(ee_morris[1]),as.factor)
names(ee_morris) <- c("parametres","effet_elementaire","delta_X","delta_Y")


morris<-pPlan[which(pPlan[1]=="R"),]

for (j in 1:9){
  morris["mean_effect",j]<-round(mean((ee_morris[which(ee_morris[1]==names(morris)[j]),2]),
                                      na.rm=TRUE),3)
  
  morris["mean_absolute_effect",j]<-round(mean(abs(ee_morris[which(ee_morris[1]==names(morris)[j]),2]),
                                               na.rm=TRUE),3)
  
  morris["sd_effect",j]<-round(sd(ee_morris[which(ee_morris[1]==names(morris)[j]),2],
                                  na.rm=TRUE),3)
  
  morris["delta_X",j]<-round(mean(ee_morris[which(ee_morris[1]==names(morris)[j]),3],
                                  na.rm=TRUE),3)
  
  morris["delta_Y",j]<-round(mean(ee_morris[which(ee_morris[1]==names(morris)[j]),4],
                                  na.rm=TRUE),3)
}
morris<-t(morris)

plt<-data.frame(morris)

#Figure Plan de Morris

plot(x = plt$mean_absolute_effect,
     y = plt$sd_effect,
     pch = 16, frame = FALSE,
     xlab = "moyenne des effets �l�mentaires absolus", 
     ylab = "l'�cart-type des effets �l�mentaires",
     col = c(1:9))
abline(lm(sd_effect ~ mean_absolute_effect,data=plt), col="grey", lwd=3)
#text(sd_effect ~ mean_effect, labels=rownames(plt),data=plt, cex=0.9, font=2)
text(plt$mean_absolute_effect,plt$sd_effect,labels=rownames(plt), cex= 0.7, offset = 10)

write.csv2(ee_morris, file = "effet_elementaire_morris.csv")

#Rang de Morris
rank<-data.frame(morris[,2:3])
rank$sum<-(rank$sd_effect+rank$mean_absolute_effect)
rank<-rank[order(rank$sum),]
rank$Rang_Morris<-sort(1:9,decreasing=TRUE)
rank<-rank[order(rank$Rang_Morris),-3]

rank
