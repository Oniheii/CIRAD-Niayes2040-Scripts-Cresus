
## ANALYSE DE SENSIBILITE DU MODEL HYDRO R-NIAYES 2040

#Les fonctions
create_folder=function(x,path=getwd()){
  
  for (f in x){
    
    folder<-file.path(path, f)
    
    if (!dir.exists(folder)){
      dir.create(folder)
      print(paste(f,"has been created!"))
    } else {
      print(paste(folder,"already exists!"))}
  }
}

rcsv_sep=function(file_path){
  L <- readLines(file_path, n = 1)
  if (grepl(";", L)) read.csv2(file_path) else read.csv(file_path)
}

normaliz_zero<-function(x){
  x<-na.omit(x)
  min<-min(x)
  max<-max(x)
  
  val<-as.numeric(lapply(x,function(y) (y-min)/(max-min)))
  return(val)
}


### M�thode de Morris

### a-)  Plan d'exp�rience
#### la table des RMSE
rmse<-rcsv_sep('data/tableau_rsme.csv')[-1]

#names(rmse)[4:7]<-c("varperm","varstock","nbiterations","consourb")
rmse[3:7]<-data.frame(lapply(rmse[3:7],as.numeric))

set<-subset(rmse,resolution==300|
              resolution==500|
              resolution==700|
              resolution==900)

#set<-subset(rmse, resolution==800|resolution==1000)
#set<-subset(set, varstock==30|varstock==60)
#set<-subset(set, varperm==5e-04|varperm==0.001)



rmse_norm<-set
rmse_norm[3:6]<-data.frame(sapply(set[3:6],normaliz_zero))

head(set[c(3:8,10)],3)
head(rmse_norm[c(3:8,10:12)],3)


#### b-) Plan One At Time (OAT)

pPlan<-sapply(rmse[3:6],unique)

pPlan<- data.frame(lapply(pPlan, function(x) {
  x <- unlist(x)
  length(x) <- max(lengths(pPlan))
  return(x)
}))
pPlan


poat<-rmse_norm[c(3:6,11:12)]
head(poat,3)

#### c-) m�thode de Morris: Le plan de morris avec �chantillonnage radial it�r�

set.seed(123)

i<-0
EE<-c()
PARAM<-c()
choc<-c()
response<-c()

while (i<10){
  i<- i+1
  t<-c()
  T<-0
  
  #premier plan OAT
  
  ##trier au hasard l'�tat initial des param�tre du plan OAT
  L0<-sample(dim(poat)[1],1)
  input0 <- poat[L0,1:4]
  
  ##appel initial au model (r�ponse du model au set initial de param�tres)
  output0 <- poat[L0,5]
  
  while (T<10){
    #effets elementaire
    ##tirage al�atoire pour modification d'une entr�e
    to<-sample(length(input0),1)
    
    ##modification du parametre choqu�:
    input1 <- input0
    
    c<-0
    
    lt<-unique(unlist(na.omit(poat[to])))
    lt<-as.list(lt[-which(lt==input0[[to]])])
    while (c<1){
      chg<-sample(lt,1)[[1]]
      input1[to]<-chg
      
      input1<-subset(poat, 
                     consourb==input1[["consourb"]] &
                       moyirrigculture==input1[["moyirrigculture"]] &
                       varstock==input1[["varstock"]] &
                       resolution==input1[["resolution"]] )
      
      ##le pas de changement
      d<-(chg-input0[to])
      
      if (NROW(input1)>0){
        c<-1}
      if (NROW(input1)==0){input1 <- input0
      lt<-lt[-which(lt==chg)]}
    }
    
    
    ##appel au model choqu�
    output1 <- input1[,5]
    input1 <- input1[L0,1:4]
    
    ## effet �l�mentaire EE
    EE1<-(output1-output0)/d
    EE <-c (EE,round(EE1,3))
    PARAM<- c(PARAM,names(input1)[to])
    choc<-c(choc,d)
    response<-c(response,round((output1-output0),3))
    t<-c(t,to)
    T<-sum(unique(t))
  }
}



ee_morris <- data.frame(cbind(unlist(PARAM),
                              unlist(EE),
                              unlist(choc),
                              unlist(response)))
rownames(ee_morris) <-NULL 
ee_morris[2:4]<-sapply(ee_morris[2:4],as.numeric)
ee_morris[1]<-sapply(unlist(ee_morris[1]),as.factor)
names(ee_morris) <- c("parametres","effet_elementaire","delta_X","delta_Y")

morris<-pPlan[which(pPlan[1]=="R"),]

for (j in 1:4){
  morris["mean_effect",j]<-round(mean((ee_morris[which(ee_morris[1]==names(morris)[j]),2]),
                                      na.rm=TRUE),3)
  
  morris["mean_absolute_effect",j]<-round(mean(abs(ee_morris[which(ee_morris[1]==names(morris)[j]),2]),
                                               na.rm=TRUE),3)
  
  morris["sd_effect",j]<-round(sd(ee_morris[which(ee_morris[1]==names(morris)[j]),2],
                                  na.rm=TRUE),3)
  
  morris["delta_X",j]<-round(mean(ee_morris[which(ee_morris[1]==names(morris)[j]),3],
                                  na.rm=TRUE),3)
  
  morris["delta_Y",j]<-round(mean(ee_morris[which(ee_morris[1]==names(morris)[j]),4],
                                  na.rm=TRUE),3)
}
morris<-t(morris)

morris

plt<-data.frame(morris)

plot(x = plt$mean_absolute_effect,
     y = plt$sd_effect,
     pch = 16, frame = FALSE,
     xlab = "moyenne des effets �l�mentaires absolus", 
     ylab = "l'�cart-type des effets �l�mentaires",
     col = c(1:5))
abline(lm(sd_effect ~ mean_absolute_effect,data=plt), col="grey", lwd=3)
#text(sd_effect ~ mean_effect, labels=rownames(plt),data=plt, cex=0.9, font=2)
text(plt$mean_absolute_effect,plt$sd_effect,labels=rownames(plt), cex= 0.7, offset = 10)



write.csv2(ee_morris, file = "output/effet_elementaire_morris.csv")

rank<-data.frame(morris[,2:3])
rank$sum<-(rank$sd_effect+rank$mean_absolute_effect)
rank<-rank[order(rank$sum),]
rank$Rang_Morris<-sort(1:9,decreasing=TRUE)
rank<-rank[order(rank$Rang_Morris),-3]

rank
















































































